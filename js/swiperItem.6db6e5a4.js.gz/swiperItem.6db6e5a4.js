const e=new Swiper(".image-gallery__thumbs",{slidesPerView:"auto",freeMode:!0,watchSlidesProgress:!0});new Swiper(".image-gallery__main",{spaceBetween:10,zoom:!0,thumbs:{swiper:e}});
//# sourceMappingURL=swiperItem.6db6e5a4.js.map
