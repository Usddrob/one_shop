new Swiper(".swiper-per-view",{direction:"horizontal",loop:!1,slidesPerView:"auto",spaceBetween:60});
//# sourceMappingURL=swiperPerView.33a64a73.js.map
